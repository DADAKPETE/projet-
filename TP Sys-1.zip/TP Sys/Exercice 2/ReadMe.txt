1. Une valeur qui varie mais qui est toujours inférieur ou égale à 300.

2. Pour résoudre le problème il faut attendre que chaque processus passe son tour pour opérer

3. (Implémentation)
